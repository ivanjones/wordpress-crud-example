<?php
/*
Plugin Name: Schools
Plugin URI: http://sinetiks.com
Description:
Author: sinetiks.com
Version: 1_IJ
Author URI: http://sinetiks.com
*/
// function to create the DB / Options / Defaults	

include_once 'includes/schools-list.php';
include_once 'includes/schools-create.php';
include_once 'includes/schools-update.php';

				
function ss_options_install() {

    global $wpdb;

    $table_name = $wpdb->prefix . "school";
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE $table_name (
            `id` varchar(3) CHARACTER SET utf8 NOT NULL,
            `name` varchar(50) CHARACTER SET utf8 NOT NULL,
            PRIMARY KEY (`id`)
          ) $charset_collate; ";

    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta($sql);
}

// run the install scripts upon plugin activation
register_activation_hook(__FILE__, 'ss_options_install');

//menu items
add_action('admin_menu','schools_modifymenu');
function schools_modifymenu() {
	
	//this is the main item for the menu
	add_menu_page('Schools','Schools','manage_options','schools_list','schools_list');
	
	//this is a submenu
	add_submenu_page('schools_list','Add New School','Add New','manage_options','schools_create','schools_create');
	
	//this submenu is HIDDEN, however, we need to add it anyways
	add_submenu_page(null,'Update School','Update','manage_options','schools_update', 'schools_update');
}
//define('ROOTDIR', plugin_dir_path(__FILE__));
//require_once(ROOTDIR . 'includes/schools-list.php');
//require_once(ROOTDIR . 'includes/schools-create.php');
//require_once(ROOTDIR . 'includes/schools-update.php');
